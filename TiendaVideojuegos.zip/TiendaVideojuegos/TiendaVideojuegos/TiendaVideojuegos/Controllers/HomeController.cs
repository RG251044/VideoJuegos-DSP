using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        // GET: /Home/Index - Cat�logo de videojuegos
        public async Task<IActionResult> Index(string buscar, int? categoriaId)
        {
            var juegos = _context.Videojuegos
                .Include(v => v.Categoria)
                .Where(v => v.Estado && v.Stock > 0)
                .AsQueryable();

            // Filtrar por b�squeda
            if (!string.IsNullOrWhiteSpace(buscar))
            {
                juegos = juegos.Where(v => v.Titulo.Contains(buscar) ||
                                           v.Descripcion.Contains(buscar));
            }

            // Filtrar por categor�a
            if (categoriaId.HasValue)
            {
                juegos = juegos.Where(v => v.ID_Categoria == categoriaId);
            }

            ViewBag.Categorias = await _context.Categorias.ToListAsync();
            ViewBag.BuscarTexto = buscar;
            ViewBag.CategoriaSeleccionada = categoriaId;

            return View(await juegos.OrderByDescending(v => v.FechaLanzamiento).ToListAsync());
        }

        // GET: /Home/Detalles/5
        public async Task<IActionResult> Detalles(int id)
        {
            var juego = await _context.Videojuegos
                .Include(v => v.Categoria)
                .FirstOrDefaultAsync(v => v.ID_Videojuego == id);

            if (juego == null)
                return NotFound();

            return View(juego);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}