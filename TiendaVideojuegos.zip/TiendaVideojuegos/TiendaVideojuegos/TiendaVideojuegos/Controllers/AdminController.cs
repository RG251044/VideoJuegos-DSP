﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public AdminController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // Método para verificar si el usuario es Admin
        private bool EsAdmin()
        {
            var rol = HttpContext.Session.GetString("UsuarioRol");
            return rol == "Admin";
        }

        // GET: /Admin
        public async Task<IActionResult> Index()
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            var juegos = await _context.Videojuegos
                .Include(v => v.Categoria)
                .OrderByDescending(v => v.ID_Videojuego)
                .ToListAsync();

            return View(juegos);
        }

        // GET: /Admin/Crear
        public IActionResult Crear()
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            ViewBag.Categorias = _context.Categorias.ToList();
            return View();
        }

        // POST: /Admin/Crear
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear(Videojuego juego, IFormFile Imagen)
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            if (ModelState.IsValid)
            {
                if (Imagen != null && Imagen.Length > 0)
                {
                    var fileName = Guid.NewGuid().ToString() + Path.GetExtension(Imagen.FileName);
                    var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "juegos");

                    // Crear directorio si no existe
                    if (!Directory.Exists(uploadsFolder))
                        Directory.CreateDirectory(uploadsFolder);

                    var filePath = Path.Combine(uploadsFolder, fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                        await Imagen.CopyToAsync(stream);

                    juego.ImagenURL = "/images/juegos/" + fileName;
                }

                juego.Estado = true;
                _context.Videojuegos.Add(juego);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Videojuego creado exitosamente.";
                return RedirectToAction("Index");
            }

            ViewBag.Categorias = _context.Categorias.ToList();
            return View(juego);
        }

        // GET: /Admin/Editar/5
        public async Task<IActionResult> Editar(int id)
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            var juego = await _context.Videojuegos.FindAsync(id);
            if (juego == null)
                return NotFound();

            ViewBag.Categorias = _context.Categorias.ToList();
            return View(juego);
        }

        // POST: /Admin/Editar/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, Videojuego juego, IFormFile Imagen)
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            if (id != juego.ID_Videojuego)
                return BadRequest();

            if (ModelState.IsValid)
            {
                try
                {
                    if (Imagen != null && Imagen.Length > 0)
                    {
                        var fileName = Guid.NewGuid().ToString() + Path.GetExtension(Imagen.FileName);
                        var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "juegos");

                        if (!Directory.Exists(uploadsFolder))
                            Directory.CreateDirectory(uploadsFolder);

                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                            await Imagen.CopyToAsync(stream);

                        juego.ImagenURL = "/images/juegos/" + fileName;
                    }

                    _context.Update(juego);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Videojuego actualizado exitosamente.";
                    return RedirectToAction("Index");
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Videojuegos.Any(v => v.ID_Videojuego == id))
                        return NotFound();
                    throw;
                }
            }

            ViewBag.Categorias = _context.Categorias.ToList();
            return View(juego);
        }

        // POST: /Admin/Eliminar/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Eliminar(int id)
        {
            if (!EsAdmin())
                return RedirectToAction("Login", "Account");

            var juego = await _context.Videojuegos.FindAsync(id);
            if (juego != null)
            {
                // Soft delete: marcar como inactivo en lugar de eliminar
                juego.Estado = false;
                _context.Update(juego);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Videojuego eliminado exitosamente.";
            }

            return RedirectToAction("Index");
        }
    }
}