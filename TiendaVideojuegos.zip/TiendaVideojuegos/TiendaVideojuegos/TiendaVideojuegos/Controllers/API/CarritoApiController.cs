﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarritoApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public CarritoApiController(ApplicationDbContext context) => _context = context;

        // GET: api/CarritoApi/Usuario/5
        [HttpGet("Usuario/{userId}")]
        public async Task<ActionResult<IEnumerable<CarritoCompra>>> GetCarritoUsuario(int userId)
        {
            return await _context.CarritoCompra
                .Include(c => c.Videojuego)
                .Where(c => c.ID_Usuario == userId)
                .ToListAsync();
        }

        // POST: api/CarritoApi
        [HttpPost]
        public async Task<ActionResult<CarritoCompra>> AgregarCarrito(CarritoCompra item)
        {
            var juego = await _context.Videojuegos.FindAsync(item.ID_Videojuego);
            if (juego == null) return BadRequest("Juego no encontrado");

            item.TotalCarrito = item.Cantidad * juego.Precio;
            _context.CarritoCompra.Add(item);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCarritoUsuario), new { userId = item.ID_Usuario }, item);
        }

        // DELETE: api/CarritoApi/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarCarrito(int id)
        {
            var item = await _context.CarritoCompra.FindAsync(id);
            if (item == null) return NotFound();
            _context.CarritoCompra.Remove(item);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
