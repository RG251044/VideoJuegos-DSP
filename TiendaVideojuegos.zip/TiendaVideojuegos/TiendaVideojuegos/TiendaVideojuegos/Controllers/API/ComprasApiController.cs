﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComprasApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public ComprasApiController(ApplicationDbContext context) => _context = context;

        // GET: api/ComprasApi/Usuario/5
        [HttpGet("Usuario/{userId}")]
        public async Task<ActionResult<IEnumerable<Compra>>> GetComprasUsuario(int userId)
        {
            return await _context.Compras
                .Where(c => c.ID_Usuario == userId)
                .ToListAsync();
        }

        // POST: api/ComprasApi
        [HttpPost]
        public async Task<ActionResult<Compra>> PostCompra(Compra compra)
        {
            _context.Compras.Add(compra);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetComprasUsuario), new { userId = compra.ID_Usuario }, compra);
        }

        // DELETE: api/ComprasApi/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCompra(int id)
        {
            var compra = await _context.Compras.FindAsync(id);
            if (compra == null) return NotFound();
            _context.Compras.Remove(compra);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
