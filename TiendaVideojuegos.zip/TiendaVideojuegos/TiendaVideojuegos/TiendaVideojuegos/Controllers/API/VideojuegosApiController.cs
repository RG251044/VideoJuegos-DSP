﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers.API
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideojuegosApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public VideojuegosApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/VideojuegosApi
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Videojuego>>> GetVideojuegos()
        {
            return await _context.Videojuegos.Include(v => v.Categoria).ToListAsync();
        }

        // GET: api/VideojuegosApi/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Videojuego>> GetVideojuego(int id)
        {
            var juego = await _context.Videojuegos.Include(v => v.Categoria)
                .FirstOrDefaultAsync(v => v.ID_Videojuego == id);
            if (juego == null) return NotFound();
            return juego;
        }

        // POST: api/VideojuegosApi
        [HttpPost]
        public async Task<ActionResult<Videojuego>> PostVideojuego(Videojuego juego)
        {
            _context.Videojuegos.Add(juego);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetVideojuego), new { id = juego.ID_Videojuego }, juego);
        }

        // PUT: api/VideojuegosApi/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVideojuego(int id, Videojuego juego)
        {
            if (id != juego.ID_Videojuego) return BadRequest();
            _context.Entry(juego).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/VideojuegosApi/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVideojuego(int id)
        {
            var juego = await _context.Videojuegos.FindAsync(id);
            if (juego == null) return NotFound();
            _context.Videojuegos.Remove(juego);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
