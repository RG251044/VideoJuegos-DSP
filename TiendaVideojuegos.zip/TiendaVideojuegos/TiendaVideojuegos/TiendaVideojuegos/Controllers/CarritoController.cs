﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Data;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Controllers
{
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: /Carrito
        public async Task<IActionResult> Index()
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return RedirectToAction("Login", "Account");

            var carrito = await _context.CarritoCompra
                .Include(c => c.Videojuego)
                .ThenInclude(v => v.Categoria)
                .Where(c => c.ID_Usuario == userId)
                .ToListAsync();

            return View(carrito);
        }

        // POST: /Carrito/Agregar
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Agregar(int juegoId, int cantidad = 1)
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return Json(new { success = false, message = "Debe iniciar sesión" });

            var juego = await _context.Videojuegos.FindAsync(juegoId);
            if (juego == null)
                return Json(new { success = false, message = "Juego no encontrado" });

            if (juego.Stock < cantidad)
                return Json(new { success = false, message = "Stock insuficiente" });

            var existente = await _context.CarritoCompra
                .FirstOrDefaultAsync(c => c.ID_Usuario == userId && c.ID_Videojuego == juegoId);

            if (existente != null)
            {
                existente.Cantidad += cantidad;
                existente.TotalCarrito = existente.Cantidad * juego.Precio;
                existente.FechaAgregado = DateTime.Now;
            }
            else
            {
                _context.CarritoCompra.Add(new CarritoCompra
                {
                    ID_Usuario = userId.Value,
                    ID_Videojuego = juegoId,
                    Cantidad = cantidad,
                    TotalCarrito = juego.Precio * cantidad,
                    FechaAgregado = DateTime.Now
                });
            }

            await _context.SaveChangesAsync();
            return Json(new { success = true, message = "Agregado al carrito" });
        }

        // POST: /Carrito/Eliminar/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Eliminar(int id)
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return RedirectToAction("Login", "Account");

            var item = await _context.CarritoCompra
                .FirstOrDefaultAsync(c => c.ID_Carrito == id && c.ID_Usuario == userId);

            if (item != null)
            {
                _context.CarritoCompra.Remove(item);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Producto eliminado del carrito.";
            }

            return RedirectToAction("Index");
        }

        // GET: /Carrito/Checkout
        public async Task<IActionResult> Checkout()
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return RedirectToAction("Login", "Account");

            var carrito = await _context.CarritoCompra
                .Include(c => c.Videojuego)
                .Where(c => c.ID_Usuario == userId)
                .ToListAsync();

            if (!carrito.Any())
            {
                TempData["ErrorMessage"] = "El carrito está vacío.";
                return RedirectToAction("Index");
            }

            decimal total = carrito.Sum(c => c.TotalCarrito);
            return View(total);
        }

        // POST: /Carrito/ConfirmarCompra
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmarCompra(string metodoPago)
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return RedirectToAction("Login", "Account");

            if (string.IsNullOrWhiteSpace(metodoPago))
            {
                TempData["ErrorMessage"] = "Debe seleccionar un método de pago.";
                return RedirectToAction("Checkout");
            }

            var carrito = await _context.CarritoCompra
                .Include(c => c.Videojuego)
                .Where(c => c.ID_Usuario == userId)
                .ToListAsync();

            if (!carrito.Any())
            {
                TempData["ErrorMessage"] = "El carrito está vacío.";
                return RedirectToAction("Index");
            }

            // Verificar stock
            foreach (var item in carrito)
            {
                if (item.Videojuego.Stock < item.Cantidad)
                {
                    TempData["ErrorMessage"] = $"Stock insuficiente para {item.Videojuego.Titulo}";
                    return RedirectToAction("Index");
                }
            }

            decimal totalCompra = carrito.Sum(c => c.TotalCarrito);

            // Crear la compra
            var compra = new Compra
            {
                ID_Usuario = userId.Value,
                FechaCompra = DateTime.Now,
                TotalCompra = totalCompra,
                MetodoPago = metodoPago,
                Estado = "Completada"
            };

            _context.Compras.Add(compra);
            await _context.SaveChangesAsync();

            // Crear los detalles de compra y actualizar stock
            foreach (var item in carrito)
            {
                var detalle = new DetalleCompra
                {
                    ID_Compra = compra.ID_Compra,
                    ID_Videojuego = item.ID_Videojuego,
                    Cantidad = item.Cantidad,
                    PrecioUnitario = item.Videojuego.Precio,
                    Subtotal = item.TotalCarrito
                };

                _context.DetalleCompra.Add(detalle);

                // Actualizar stock
                item.Videojuego.Stock -= item.Cantidad;
            }

            // Limpiar el carrito
            _context.CarritoCompra.RemoveRange(carrito);
            await _context.SaveChangesAsync();

            TempData["CompraId"] = compra.ID_Compra;
            return RedirectToAction("Confirmacion");
        }

        // GET: /Carrito/Confirmacion
        public IActionResult Confirmacion()
        {
            int? userId = HttpContext.Session.GetInt32("UsuarioId");
            if (userId == null)
                return RedirectToAction("Login", "Account");

            return View();
        }
    }
}