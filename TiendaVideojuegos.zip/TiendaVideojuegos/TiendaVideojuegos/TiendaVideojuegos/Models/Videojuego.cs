﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TiendaVideojuegos.Models
{
    public class Videojuego
    {
        [Key]
        public int ID_Videojuego { get; set; }

        [Required, StringLength(200)]
        public string Titulo { get; set; }

        [ForeignKey("Categoria")]
        public int? ID_Categoria { get; set; }
        public Categoria? Categoria { get; set; }

        [StringLength(100)]
        public string? Plataforma { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Precio { get; set; }

        public int Stock { get; set; } = 0;

        public string? Descripcion { get; set; }

        public string? ImagenURL { get; set; }

        public string? Desarrolladora { get; set; }

        public DateTime? FechaLanzamiento { get; set; }

        public bool Estado { get; set; } = true;
    }
}
