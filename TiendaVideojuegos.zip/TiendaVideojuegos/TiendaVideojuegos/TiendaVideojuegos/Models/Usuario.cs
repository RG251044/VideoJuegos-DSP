﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TiendaVideojuegos.Models
{
    public class Usuario
    {
        [Key]
        public int ID_Usuario { get; set; }

        [Required, StringLength(50)]
        public string Nombre { get; set; }

        [Required, StringLength(50)]
        public string Apellido { get; set; }

        [Required, StringLength(100)]
        [EmailAddress]
        public string Correo { get; set; }

        [StringLength(50)]
        public string? Telefono { get; set; }

        [Required]
        public string Contrasena { get; set; }  // Se recomienda hash

        [StringLength(20)]
        public string Rol { get; set; } = "Administrado";

        public DateTime FechaRegistro { get; set; } = DateTime.Now;

        public bool Estado { get; set; } = true;
    }
}
