﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TiendaVideojuegos.Models
{
    public class Resena
    {
        [Key]
        public int ID_Resena { get; set; }

        [ForeignKey("Usuario")]
        public int ID_Usuario { get; set; }
        public Usuario Usuario { get; set; }

        [ForeignKey("Videojuego")]
        public int ID_Videojuego { get; set; }
        public Videojuego Videojuego { get; set; }

        [Range(1, 5)]
        public int Calificacion { get; set; }

        public string? Comentario { get; set; }

        public DateTime FechaResena { get; set; } = DateTime.Now;
    }
}
