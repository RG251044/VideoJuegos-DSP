﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TiendaVideojuegos.Models
{
    public class Compra
    {
        [Key]
        public int ID_Compra { get; set; }

        [ForeignKey("Usuario")]
        public int ID_Usuario { get; set; }
        public Usuario Usuario { get; set; }

        public DateTime FechaCompra { get; set; } = DateTime.Now;

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal TotalCompra { get; set; }

        [StringLength(50)]
        public string MetodoPago { get; set; } = "Tarjeta";

        [StringLength(50)]
        public string Estado { get; set; } = "Completada";
    }
}
