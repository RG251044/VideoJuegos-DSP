﻿namespace TiendaVideojuegos.Models
{
    public class RegisterModel
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public string Contrasena { get; set; }
    }
}
