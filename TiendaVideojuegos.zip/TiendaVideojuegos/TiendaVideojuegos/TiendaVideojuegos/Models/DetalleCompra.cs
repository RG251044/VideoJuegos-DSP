﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TiendaVideojuegos.Models
{
    public class DetalleCompra
    {
        [Key]
        public int ID_Detalle { get; set; }

        [ForeignKey("Compra")]
        public int ID_Compra { get; set; }
        public Compra Compra { get; set; }

        [ForeignKey("Videojuego")]
        public int ID_Videojuego { get; set; }
        public Videojuego Videojuego { get; set; }

        [Required]
        public int Cantidad { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal PrecioUnitario { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal Subtotal { get; set; }
    }
}
