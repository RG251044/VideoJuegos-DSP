﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TiendaVideojuegos.Models
{
    public class CarritoCompra
    {
        [Key]
        public int ID_Carrito { get; set; }

        [ForeignKey("Usuario")]
        public int ID_Usuario { get; set; }
        public Usuario Usuario { get; set; }

        [ForeignKey("Videojuego")]
        public int ID_Videojuego { get; set; }
        public Videojuego Videojuego { get; set; }

        [Required]
        public int Cantidad { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal TotalCarrito { get; set; }

        public DateTime FechaAgregado { get; set; } = DateTime.Now;
    }
}
