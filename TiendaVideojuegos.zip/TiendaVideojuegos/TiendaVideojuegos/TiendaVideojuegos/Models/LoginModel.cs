﻿namespace TiendaVideojuegos.Models
{
    public class LoginModel
    {
        public string Correo { get; set; }
        public string Contrasena { get; set; }
    }
}
