﻿using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // Tablas
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Videojuego> Videojuegos { get; set; }
        public DbSet<CarritoCompra> CarritoCompra { get; set; }
        public DbSet<Compra> Compras { get; set; }
        public DbSet<DetalleCompra> DetalleCompra { get; set; }
        public DbSet<Resena> Resenas { get; set; }

        // Opcional: Configurar nombres de tabla (por si EF cambia)
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Usuario>().ToTable("Usuarios");
            modelBuilder.Entity<Categoria>().ToTable("Categorias");
            modelBuilder.Entity<Videojuego>().ToTable("Videojuegos");
            modelBuilder.Entity<CarritoCompra>().ToTable("CarritoCompra");
            modelBuilder.Entity<Compra>().ToTable("Compras");
            modelBuilder.Entity<DetalleCompra>().ToTable("DetalleCompra");
            modelBuilder.Entity<Resena>().ToTable("Resenas");
        }
    }
}
