﻿using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using TiendaVideojuegos.Models;

namespace TiendaVideojuegos.Data
{
    public static class DbSeeder
    {
        public static async Task SeedAsync(ApplicationDbContext context)
        {
            try
            {
                // Asegurar que la base de datos está creada
                await context.Database.MigrateAsync();

                // Crear Categorías si no existen
                if (!await context.Categorias.AnyAsync())
                {
                    var categorias = new List<Categoria>
                    {
                        new Categoria { Nombre = "Acción", Descripcion = "Juegos de acción y aventura" },
                        new Categoria { Nombre = "RPG", Descripcion = "Juegos de rol" },
                        new Categoria { Nombre = "Estrategia", Descripcion = "Juegos de estrategia" },
                        new Categoria { Nombre = "Deportes", Descripcion = "Juegos deportivos" },
                        new Categoria { Nombre = "Simulación", Descripcion = "Juegos de simulación" },
                        new Categoria { Nombre = "Aventura", Descripcion = "Juegos de aventura" },
                        new Categoria { Nombre = "Terror", Descripcion = "Juegos de terror y supervivencia" }
                    };

                    await context.Categorias.AddRangeAsync(categorias);
                    await context.SaveChangesAsync();
                    Console.WriteLine("✅ Categorías creadas exitosamente");
                }

                // Crear Usuario Administrador si no existe
                if (!await context.Usuarios.AnyAsync(u => u.Rol == "Admin"))
                {
                    var adminPassword = ComputeSha256Hash("admin123"); // Contraseña: admin123

                    var admin = new Usuario
                    {
                        Nombre = "Admin",
                        Apellido = "Sistema",
                        Correo = "ad@tienda.com",
                        Contrasena = adminPassword,
                        Telefono = "7777-7777",
                        Rol = "Admin",
                        Estado = true,
                        FechaRegistro = DateTime.Now
                    };

                    await context.Usuarios.AddAsync(admin);
                    await context.SaveChangesAsync();
                    Console.WriteLine("✅ Usuario Administrador creado");
                    Console.WriteLine("📧 Email: admin@tienda.com");
                    Console.WriteLine("🔑 Contraseña: admin123");
                }

                // Crear Usuarios de prueba si no existen
                if (await context.Usuarios.CountAsync() < 3)
                {
                    var clientePassword = ComputeSha256Hash("cliente123");

                    var clientes = new List<Usuario>
                    {
                        new Usuario
                        {
                            Nombre = "Juan",
                            Apellido = "Pérez",
                            Correo = "juan@email.com",
                            Contrasena = clientePassword,
                            Telefono = "7000-0001",
                            Rol = "Cliente",
                            Estado = true,
                            FechaRegistro = DateTime.Now
                        },
                        new Usuario
                        {
                            Nombre = "María",
                            Apellido = "García",
                            Correo = "maria@email.com",
                            Contrasena = clientePassword,
                            Telefono = "7000-0002",
                            Rol = "Cliente",
                            Estado = true,
                            FechaRegistro = DateTime.Now
                        }
                    };

                    await context.Usuarios.AddRangeAsync(clientes);
                    await context.SaveChangesAsync();
                    Console.WriteLine("✅ Usuarios de prueba creados");
                    Console.WriteLine("📧 juan@email.com / maria@email.com");
                    Console.WriteLine("🔑 Contraseña: cliente123");
                }

                // Crear Videojuegos de ejemplo si no existen
                if (!await context.Videojuegos.AnyAsync())
                {
                    var categoriaAccion = await context.Categorias.FirstAsync(c => c.Nombre == "Acción");
                    var categoriaRPG = await context.Categorias.FirstAsync(c => c.Nombre == "RPG");
                    var categoriaDeportes = await context.Categorias.FirstAsync(c => c.Nombre == "Deportes");

                    var juegos = new List<Videojuego>
                    {
                        new Videojuego
                        {
                            Titulo = "The Last of Us Part II",
                            ID_Categoria = categoriaAccion.ID_Categoria,
                            Plataforma = "PlayStation 5",
                            Precio = 59.99m,
                            Stock = 50,
                            Descripcion = "Una experiencia emocional intensa en un mundo post-apocalíptico.",
                            ImagenURL = "/images/juegos/default.jpg",
                            Desarrolladora = "Naughty Dog",
                            FechaLanzamiento = new DateTime(2020, 6, 19),
                            Estado = true
                        },
                        new Videojuego
                        {
                            Titulo = "Elden Ring",
                            ID_Categoria = categoriaRPG.ID_Categoria,
                            Plataforma = "PC, PS5, Xbox",
                            Precio = 69.99m,
                            Stock = 35,
                            Descripcion = "Un RPG de acción épico creado por FromSoftware y George R.R. Martin.",
                            ImagenURL = "/images/juegos/default.jpg",
                            Desarrolladora = "FromSoftware",
                            FechaLanzamiento = new DateTime(2022, 2, 25),
                            Estado = true
                        },
                        new Videojuego
                        {
                            Titulo = "FIFA 24",
                            ID_Categoria = categoriaDeportes.ID_Categoria,
                            Plataforma = "PC, PS5, Xbox",
                            Precio = 49.99m,
                            Stock = 100,
                            Descripcion = "El juego de fútbol más realista con equipos y ligas oficiales.",
                            ImagenURL = "/images/juegos/default.jpg",
                            Desarrolladora = "EA Sports",
                            FechaLanzamiento = new DateTime(2023, 9, 29),
                            Estado = true
                        },
                        new Videojuego
                        {
                            Titulo = "God of War Ragnarök",
                            ID_Categoria = categoriaAccion.ID_Categoria,
                            Plataforma = "PlayStation 5",
                            Precio = 69.99m,
                            Stock = 45,
                            Descripcion = "Kratos y Atreus enfrentan el Ragnarök en esta épica aventura nórdica.",
                            ImagenURL = "/images/juegos/default.jpg",
                            Desarrolladora = "Santa Monica Studio",
                            FechaLanzamiento = new DateTime(2022, 11, 9),
                            Estado = true
                        },
                        new Videojuego
                        {
                            Titulo = "Baldur's Gate 3",
                            ID_Categoria = categoriaRPG.ID_Categoria,
                            Plataforma = "PC, PS5",
                            Precio = 59.99m,
                            Stock = 30,
                            Descripcion = "RPG épico basado en Dungeons & Dragons con decisiones que importan.",
                            ImagenURL = "/images/juegos/default.jpg",
                            Desarrolladora = "Larian Studios",
                            FechaLanzamiento = new DateTime(2023, 8, 3),
                            Estado = true
                        }
                    };

                    await context.Videojuegos.AddRangeAsync(juegos);
                    await context.SaveChangesAsync();
                    Console.WriteLine("✅ Videojuegos de ejemplo creados");
                }

                Console.WriteLine("\n🎉 Base de datos inicializada correctamente!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error en el Seeder: " + ex.Message);
                if (ex.InnerException != null)
                {
                    Console.WriteLine("➡️ Detalle interno: " + ex.InnerException.Message);
                }
            }
        }

        private static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                    builder.Append(bytes[i].ToString("x2"));
                return builder.ToString();
            }
        }
    }
}
